# estructura-dato-parcial-corte-1-2024-b
