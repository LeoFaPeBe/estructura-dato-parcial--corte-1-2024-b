import java.util.Scanner;
import javax.swing.*;

public class Programacompra {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double descuento;
        double ValorUnitario;
        int cantidad;

        System.out.print("Ingrese el nombre del cliente: ");
        String NombreCliente = scanner.nextLine();

        System.out.print("Ingrese el nombre del producto: ");
        String NombreProducto = scanner.nextLine();


        while (true) {
            System.out.print("Ingrese el valor unitario mayor a 0: ");
            ValorUnitario= scanner.nextDouble();
            if (ValorUnitario > 0) {
                break;
            } else {
                System.out.println("Error en la entrada de datos. Valor unitario debe ser mayor a cero.");
                return;
            }
        }

        while (true) {
            System.out.print("Ingrese la cantidad a comprar mayor a 0: ");
            cantidad = scanner.nextInt();
            if (cantidad > 0) {
                break;
            } else {
                System.out.println("Error en la entrada de datos. La cantidad debe ser mayor a cero.");
                return;
            }
        }

        double valorBruto = ValorUnitario * cantidad;

        if (cantidad < 10) {
            descuento = 0;
        } else if (cantidad < 20) {
            descuento = valorBruto * 0.05;
        } else {
            descuento = valorBruto * 0.07;
        }

        double valorNeto = valorBruto - descuento;

        System.out.println("Nombre del Cliente: " + NombreCliente);
        System.out.println("Nombre del Producto: " + NombreProducto);
        System.out.println("Valor Unitario: " + ValorUnitario);
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Valor Bruto: " + valorBruto);
        System.out.println("Valor Neto: " + valorNeto);
        System.out.println("Valor Descuento: " + descuento);
    }
}